# Export Format Reference

## Excel Export (.xlsx)

### Sheets Generated
1. **Cover** — Dashboard metadata, scope, generated date
2. **P&L Summary** — All metrics for selected filter (styled cells)
3. **SMM Detail** — Division-level data (all periods)
4. **SUN Detail** — Division-level data
5. **OliveLink Detail** — Division-level data
6. **Combine Detail** — Aggregated totals

### Styling
- Navy header: #0F2942
- Actual rows: blue accent
- Budget rows: orange accent
- Net Value Creation: cyan highlight #7DD3FC
- SUM rows: orange #FDBA74
- FY columns: blue background #DBEAFE

---

## PDF Export

### Pages
1. **Cover page** — Navy banner, title, scope, date
2. **Executive Summary** — 6 KPI cards + narrative
3. **P&L Statement** — Full table (Actual vs Budget)
4. **Performance Charts** — BCG dual panels (embedded PNG)
5. **ROI Trajectory** — ROI trend + Achievement Multiplier charts
6. **Cost Structure** — 15-component bar breakdown + key takeaways
(Ratios to Revenue slide added if Revenue data exists)

### Paper: A4 Landscape (297 × 210mm)

---

## PowerPoint Export (.pptx)

### Slides
1. **Cover** — Dark navy, gold title, scope metadata
2. **Executive Summary** — KPI grid + headline statement
3. **P&L Statement** — Styled table (mirrors P&L + ROI Report tab)
4. **Charts** — BCG dual Actual/Budget panels (Chart.js PNG images embedded)
5. **ROI & Achievement** — ROI trend + Achievement Multiplier charts
6. **Cost Composition + Actions** — Cost bars + recommended smart moves

### Slide size: 13.33" × 7.5" (LAYOUT_WIDE / 16:9)

---

## P&L + ROI Report Export (dedicated)

Matches the reference image format exactly:
- **Dark navy banner**: "ACTUAL — in USD Mn" or "BUDGET — in USD Mn"
- **Yellow/orange tag**: Division name chip
- **NVC Statement section**: Value Creation > Cost Saving > Cost Avoidance > 15 cost lines > Net Value Creation (CYAN)
- **SUM section**: Initial SUM > SUM after Saving (ORANGE)
- **Ratios section**: ROI % > Value to SUM % (CYAN)

Available as standalone PDF (landscape A4) or PPT (one slide per mode).
