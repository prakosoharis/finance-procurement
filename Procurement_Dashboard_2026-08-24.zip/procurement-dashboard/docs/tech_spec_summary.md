# Technical Specification Summary

See the full Tech Spec document generated separately via the Tech Spec Generator.

## Quick Reference

### Database: 12 Tables
users · divisions · periods · pnl_data · cost_components · fx_rates
benchmark_peers · user_sessions · data_uploads · ai_chat_history · dashboard_preferences

### Roles: 3 Levels
- admin: full read/write, manage users, upload data
- manager: read all divisions, export
- viewer: read Combine only (or division_access list)

### Key Endpoints
- GET  /api/pnl?division=&year=&quarter=&type=
- POST /api/pnl/upload     (Admin)
- GET  /api/fx/live
- POST /api/ai/chat
- GET  /api/pnl/export/xlsx|pdf|pptx

### Estimated Timeline
~12 weeks solo · ~8 weeks with 2-person team
~$45/month infrastructure (Supabase Pro + Vercel Pro)

See full tech_spec.html (download separately from Tech Spec Generator tab).
