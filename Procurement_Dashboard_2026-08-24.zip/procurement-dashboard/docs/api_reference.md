# API Reference — Procurement P&L Dashboard

## Base URL
`https://your-app.vercel.app/api`

All endpoints require: `Authorization: Bearer <supabase_jwt>`

---

## Authentication

### POST /auth/sign-in
```json
{ "email": "user@company.com", "password": "..." }
```
Returns: `{ "access_token": "...", "user": {...} }`

### POST /auth/sign-out
Invalidates current session. Returns: `{ "success": true }`

---

## P&L Data

### GET /api/pnl
Query params: `division`, `year`, `quarter`, `type` (actual|budget)

Returns array of pnl_data rows with joined cost_components.

### POST /api/pnl/upload
Content-Type: `multipart/form-data`
Field: `file` (XLSX/XLS/XLSB/CSV)

Returns: `{ "upload_id": "...", "rows_processed": 371, "divisions": ["SMM","SUN"] }`

### GET /api/pnl/export/xlsx
Query params: same as GET /api/pnl
Returns: Excel file download (Content-Disposition: attachment)

### GET /api/pnl/export/pdf
Returns: PDF file download

### GET /api/pnl/export/pptx
Returns: PowerPoint file download

---

## FX Rates

### GET /api/fx/rates
Returns: `[{ "period": "Q1 2025", "rate": 16352, "source": "BI JISDOR" }]`

### GET /api/fx/live
Returns: `{ "rate": 16782, "timestamp": "2026-08-24T..." }`

---

## Users

### GET /api/users (Admin only)
Returns: `[{ "id": "...", "email": "...", "role": "manager", "is_active": true }]`

### POST /api/users (Admin only)
```json
{ "email": "new@company.com", "full_name": "Name", "role": "manager" }
```

### PATCH /api/users/:id (Admin only)
```json
{ "role": "viewer", "division_access": ["SMM"] }
```

### DELETE /api/users/:id (Admin only)
Soft-deactivates user (is_active = false).

---

## AI Assistant

### POST /api/ai/chat
```json
{
  "messages": [{ "role": "user", "content": "What is our FY 2025 ROI?" }],
  "filter_context": { "division": "Combine", "year": "2025", "currency": "USD" }
}
```
Returns: `{ "reply": "...", "session_id": "..." }`

---

## Error Responses
```json
{ "error": "Unauthorized", "code": 401 }
{ "error": "Forbidden — insufficient role", "code": 403 }
{ "error": "Validation failed: ...", "code": 422 }
{ "error": "Internal server error", "code": 500 }
```

---

## Rate Limits
- Standard endpoints: 100 req/min per user
- AI chat: 20 req/min per user
- File upload: 5 req/min per user
