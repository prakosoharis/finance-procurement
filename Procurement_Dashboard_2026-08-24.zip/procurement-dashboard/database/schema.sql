-- ============================================================
-- PROCUREMENT P&L DASHBOARD — PostgreSQL Schema
-- Target: Supabase (PostgreSQL 15)
-- Generated: 2026-08-24
-- ============================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─── ENUMS ───────────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('admin', 'manager', 'viewer');
CREATE TYPE record_type AS ENUM ('actual', 'budget');
CREATE TYPE peer_type AS ENUM ('named', 'body');
CREATE TYPE upload_status AS ENUM ('processing', 'success', 'failed');
CREATE TYPE chat_role AS ENUM ('user', 'assistant');

-- ─── TABLE: users ─────────────────────────────────────────────
CREATE TABLE users (
  id                UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email             VARCHAR(255) NOT NULL UNIQUE,
  full_name         VARCHAR(255) NOT NULL,
  role              user_role NOT NULL DEFAULT 'viewer',
  division_access   TEXT[] DEFAULT '{}',
  is_active         BOOLEAN DEFAULT true,
  invited_by        UUID REFERENCES users(id),
  created_at        TIMESTAMPTZ DEFAULT now(),
  updated_at        TIMESTAMPTZ DEFAULT now()
);

-- ─── TABLE: divisions ─────────────────────────────────────────
CREATE TABLE divisions (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code        VARCHAR(50) NOT NULL UNIQUE,   -- SMM, SUN, OliveLink
  name        VARCHAR(255) NOT NULL,
  is_virtual  BOOLEAN DEFAULT false,          -- true for Combine (computed)
  parent_id   UUID REFERENCES divisions(id),
  created_at  TIMESTAMPTZ DEFAULT now()
);

INSERT INTO divisions (code, name) VALUES
  ('SMM',       'SMM Mining Procurement'),
  ('SUN',       'SUN Energy Procurement'),
  ('OliveLink', 'OliveLink Sourcing'),
  ('Combine',   'Combined All Divisions');

UPDATE divisions SET is_virtual = true WHERE code = 'Combine';

-- ─── TABLE: periods ───────────────────────────────────────────
CREATE TABLE periods (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  label           VARCHAR(20) NOT NULL UNIQUE,  -- Q1 2025, FY 2025, YTD Q2 2026
  year            SMALLINT NOT NULL,
  quarter         SMALLINT CHECK (quarter BETWEEN 1 AND 4),
  is_fy           BOOLEAN DEFAULT false,
  is_ytd          BOOLEAN DEFAULT false,
  ytd_through_q   SMALLINT,
  sort_order      INTEGER NOT NULL
);

-- Seed periods 2022–2026
DO $$ DECLARE y INT; q INT; s INT := 1; BEGIN
  FOR y IN 2022..2026 LOOP
    FOR q IN 1..4 LOOP
      INSERT INTO periods (label, year, quarter, is_fy, sort_order)
        VALUES ('Q' || q || ' ' || y, y, q, false, s);
      s := s + 1;
    END LOOP;
    INSERT INTO periods (label, year, is_fy, sort_order)
      VALUES ('FY ' || y, y, true, s);
    s := s + 1;
  END LOOP;
END $$;

-- ─── TABLE: pnl_data (CORE FACT TABLE) ────────────────────────
CREATE TABLE pnl_data (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  division_id           UUID NOT NULL REFERENCES divisions(id),
  period_id             UUID NOT NULL REFERENCES periods(id),
  record_type           record_type NOT NULL,
  cost_saving           NUMERIC(12,4) DEFAULT 0,
  cost_avoidance        NUMERIC(12,4) DEFAULT 0,
  total_value_creation  NUMERIC(12,4) DEFAULT 0,
  initial_sum           NUMERIC(12,4) DEFAULT 0,
  sum_after_saving      NUMERIC(12,4) DEFAULT 0,
  total_cost_incurred   NUMERIC(12,4) DEFAULT 0,
  -- Generated columns (always consistent)
  net_value_creation    NUMERIC(12,4) GENERATED ALWAYS AS
    (total_value_creation - total_cost_incurred) STORED,
  roi_pct               NUMERIC(8,4) GENERATED ALWAYS AS (
    CASE WHEN total_cost_incurred > 0
    THEN (total_value_creation - total_cost_incurred) / total_cost_incurred * 100
    ELSE 0 END) STORED,
  value_to_sum_pct      NUMERIC(8,4) GENERATED ALWAYS AS (
    CASE WHEN initial_sum > 0
    THEN total_value_creation / initial_sum * 100
    ELSE 0 END) STORED,
  revenue               NUMERIC(14,4) DEFAULT 0,
  gross_profit          NUMERIC(14,4) DEFAULT 0,
  uploaded_by           UUID REFERENCES users(id),
  source_file           VARCHAR(500),
  created_at            TIMESTAMPTZ DEFAULT now(),
  updated_at            TIMESTAMPTZ DEFAULT now(),
  UNIQUE (division_id, period_id, record_type)
);

CREATE INDEX idx_pnl_division  ON pnl_data(division_id);
CREATE INDEX idx_pnl_period    ON pnl_data(period_id);
CREATE INDEX idx_pnl_type      ON pnl_data(record_type);
CREATE INDEX idx_pnl_div_per   ON pnl_data(division_id, period_id);

-- ─── TABLE: cost_components ───────────────────────────────────
CREATE TABLE cost_components (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  pnl_data_id      UUID NOT NULL REFERENCES pnl_data(id) ON DELETE CASCADE,
  component_key    VARCHAR(50) NOT NULL,
  component_label  VARCHAR(100) NOT NULL,
  amount           NUMERIC(12,4) DEFAULT 0,
  sort_order       SMALLINT DEFAULT 0
);

CREATE INDEX idx_cc_pnl ON cost_components(pnl_data_id);

-- ─── TABLE: fx_rates ──────────────────────────────────────────
CREATE TABLE fx_rates (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  period_id        UUID NOT NULL UNIQUE REFERENCES periods(id),
  rate_idr_per_usd NUMERIC(10,2) NOT NULL,
  rate_date        DATE NOT NULL,
  source           VARCHAR(100) DEFAULT 'BI JISDOR',
  fetched_at       TIMESTAMPTZ DEFAULT now()
);

-- ─── TABLE: benchmark_peers ───────────────────────────────────
CREATE TABLE benchmark_peers (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  division_scope  VARCHAR(50) NOT NULL,
  peer_name       VARCHAR(255) NOT NULL,
  peer_type       peer_type NOT NULL,
  roi_multiple    NUMERIC(6,2) NOT NULL,
  source_label    VARCHAR(255) NOT NULL,
  source_url      VARCHAR(500),
  note            TEXT,
  is_active       BOOLEAN DEFAULT true
);

-- ─── TABLE: user_sessions (Audit Log) ─────────────────────────
CREATE TABLE user_sessions (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID NOT NULL REFERENCES users(id),
  action_type  VARCHAR(100) NOT NULL,
  payload      JSONB,
  ip_address   INET,
  created_at   TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_sessions_user ON user_sessions(user_id);
CREATE INDEX idx_sessions_time ON user_sessions(created_at DESC);

-- ─── TABLE: data_uploads ──────────────────────────────────────
CREATE TABLE data_uploads (
  id                 UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  uploaded_by        UUID REFERENCES users(id),
  filename           VARCHAR(500) NOT NULL,
  storage_path       VARCHAR(1000),
  rows_processed     INTEGER DEFAULT 0,
  divisions_updated  TEXT[] DEFAULT '{}',
  periods_updated    TEXT[] DEFAULT '{}',
  status             upload_status DEFAULT 'processing',
  error_message      TEXT,
  created_at         TIMESTAMPTZ DEFAULT now()
);

-- ─── TABLE: ai_chat_history ───────────────────────────────────
CREATE TABLE ai_chat_history (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id),
  session_id      UUID NOT NULL,
  role            chat_role NOT NULL,
  content         TEXT NOT NULL,
  filter_context  JSONB,
  created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_chat_session ON ai_chat_history(user_id, session_id);

-- ─── TABLE: dashboard_preferences ────────────────────────────
CREATE TABLE dashboard_preferences (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id           UUID NOT NULL UNIQUE REFERENCES users(id),
  theme             VARCHAR(30) DEFAULT 'dark',
  currency          CHAR(3) DEFAULT 'USD',
  default_division  VARCHAR(50) DEFAULT 'Combine',
  default_year      VARCHAR(10) DEFAULT 'All',
  default_quarter   VARCHAR(10) DEFAULT 'All',
  chart_metric      VARCHAR(20) DEFAULT 'sum',
  pnlrep_mode       VARCHAR(10) DEFAULT 'both',
  updated_at        TIMESTAMPTZ DEFAULT now()
);

-- ─── TRIGGERS: updated_at ─────────────────────────────────────
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_pnl_updated BEFORE UPDATE ON pnl_data
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE TRIGGER trg_prefs_updated BEFORE UPDATE ON dashboard_preferences
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();
