-- ============================================================
-- SEED DATA — FX Rates & Benchmark Peers
-- Run AFTER schema.sql
-- ============================================================

-- ─── BI JISDOR Quarterly Rates ────────────────────────────────
INSERT INTO fx_rates (period_id, rate_idr_per_usd, rate_date, source)
SELECT p.id, r.rate, r.rate_date::DATE, 'BI JISDOR'
FROM (VALUES
  ('Q1 2022', 14345, '2022-03-31'),
  ('Q2 2022', 14556, '2022-06-30'),
  ('Q3 2022', 14935, '2022-09-30'),
  ('Q4 2022', 15566, '2022-12-31'),
  ('FY 2022', 14871, '2022-12-31'),
  ('Q1 2023', 15242, '2023-03-31'),
  ('Q2 2023', 14866, '2023-06-30'),
  ('Q3 2023', 15214, '2023-09-30'),
  ('Q4 2023', 15629, '2023-12-31'),
  ('FY 2023', 15255, '2023-12-31'),
  ('Q1 2024', 15656, '2024-03-31'),
  ('Q2 2024', 16174, '2024-06-30'),
  ('Q3 2024', 15820, '2024-09-30'),
  ('Q4 2024', 15780, '2024-12-31'),
  ('FY 2024', 15847, '2024-12-31'),
  ('Q1 2025', 16352, '2025-03-31'),
  ('Q2 2025', 16514, '2025-06-30'),
  ('Q3 2025', 16364, '2025-09-30'),
  ('Q4 2025', 16667, '2025-12-31'),
  ('FY 2025', 16516, '2025-12-31'),
  ('Q1 2026', 16352, '2026-03-31'),
  ('Q2 2026', 16514, '2026-06-30')
) AS r(label, rate, rate_date)
JOIN periods p ON p.label = r.label
ON CONFLICT (period_id) DO UPDATE SET rate_idr_per_usd = EXCLUDED.rate_idr_per_usd;

-- ─── Benchmark Peers (Hackett, APQC, CAPS, Named Miners) ──────
INSERT INTO benchmark_peers (division_scope, peer_name, peer_type, roi_multiple, source_label, source_url, note) VALUES
-- SMM — Mining
('SMM','Hackett World-Class Procurement (Mining)','body',9.5,'Hackett Group Procurement Study 2024','https://www.thehackettgroup.com/insights/procurement-executive-insights/','World-Class threshold: NVC ÷ procurement ops cost ≥ 9.5×'),
('SMM','APQC Median Procurement (Extractive)','body',4.2,'APQC Open Standards Benchmarking','https://www.apqc.org/expertise/procurement','Median of extractive-industry procurement functions'),
('SMM','CAPS Research Mining Peer Median','body',6.8,'CAPS Research Cross-Industry Report','https://www.capsresearch.org/publications/','Mining sub-sample · procurement function NVC/cost'),
('SMM','Anglo American (Procurement Value Delivery)','named',7.2,'Anglo American Integrated Annual Report','https://www.angloamerican.com/investors/annual-reporting','Multi-year avg ~7×'),
('SMM','Freeport-McMoRan (Category Mgmt Value)','named',5.9,'Freeport-McMoRan Annual Report','https://investors.fcx.com','Copper-mining major'),
('SMM','Newmont (Procurement Function Metrics)','named',6.5,'Newmont Sustainability Report','https://www.newmont.com/sustainability','Largest gold miner'),
-- OliveLink — BPO/Sourcing
('OliveLink','Hackett World-Class (BPO/Shared Services)','body',11.0,'Hackett World-Class Procurement Study','https://www.thehackettgroup.com','Higher than in-house because shared cost base'),
('OliveLink','GPO Consortia Reported NVC/Cost','body',8.5,'Vizient GPO Value Reporting','https://www.vizientinc.com/insights','Group Purchasing Organisations'),
('OliveLink','APQC Median Sourcing BPO','body',5.5,'APQC Procurement Benchmarks','https://www.apqc.org/expertise/procurement','Median of sourcing outsourcers'),
('OliveLink','GEP (Global Procurement BPO)','named',9.2,'GEP Value Realization Studies','https://www.gep.com/insights','~$9 saved per $1 GEP operating cost'),
-- SUN — Energy/Renewables
('SUN','Hackett World-Class (Utilities/Energy)','body',10.2,'Hackett Utilities Procurement Study','https://www.thehackettgroup.com','World-Class utilities & energy procurement'),
('SUN','APQC Median Utilities Procurement','body',5.0,'APQC Utilities Benchmarks','https://www.apqc.org/expertise/procurement','Utility-sector procurement functions'),
('SUN','CAPS Renewables Peer Median','body',7.0,'CAPS Research Renewables Sector','https://www.capsresearch.org','Renewables procurement teams'),
('SUN','Enel Green Power (Procurement Value)','named',8.0,'Enel Integrated Report','https://www.enel.com/investors/reports','Italian renewables major'),
('SUN','Vestas Wind Systems (Supply Chain Value)','named',7.2,'Vestas Sustainability Report','https://www.vestas.com/en/investor/financial-reports','Wind-turbine manufacturer');
