-- ============================================================
-- ROW-LEVEL SECURITY POLICIES
-- Run AFTER schema.sql and seed_data.sql
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE users                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE pnl_data              ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_components       ENABLE ROW LEVEL SECURITY;
ALTER TABLE fx_rates              ENABLE ROW LEVEL SECURITY;
ALTER TABLE benchmark_peers       ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_sessions         ENABLE ROW LEVEL SECURITY;
ALTER TABLE data_uploads          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_chat_history       ENABLE ROW LEVEL SECURITY;
ALTER TABLE dashboard_preferences ENABLE ROW LEVEL SECURITY;

-- Helper: get current user role
CREATE OR REPLACE FUNCTION get_my_role()
RETURNS user_role AS $$
  SELECT role FROM users WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER;

-- ─── users ────────────────────────────────────────────────────
CREATE POLICY "users: own profile" ON users
  FOR ALL USING (id = auth.uid());

CREATE POLICY "users: admin sees all" ON users
  FOR ALL USING (get_my_role() = 'admin');

-- ─── pnl_data ─────────────────────────────────────────────────
-- Admin: full access
CREATE POLICY "pnl: admin full" ON pnl_data
  FOR ALL USING (get_my_role() = 'admin');

-- Manager: read all
CREATE POLICY "pnl: manager read" ON pnl_data
  FOR SELECT USING (get_my_role() = 'manager');

-- Viewer: read Combine or their division_access list
CREATE POLICY "pnl: viewer restricted" ON pnl_data
  FOR SELECT USING (
    get_my_role() = 'viewer' AND (
      division_id = (SELECT id FROM divisions WHERE code = 'Combine')
      OR
      division_id = ANY(
        SELECT unnest(division_access)::UUID FROM users WHERE id = auth.uid()
      )
    )
  );

-- ─── cost_components ──────────────────────────────────────────
-- Inherit access through pnl_data
CREATE POLICY "cost_components: via pnl" ON cost_components
  FOR SELECT USING (
    EXISTS (SELECT 1 FROM pnl_data WHERE id = cost_components.pnl_data_id)
  );

-- Admin can insert/update/delete
CREATE POLICY "cost_components: admin write" ON cost_components
  FOR ALL USING (get_my_role() = 'admin');

-- ─── fx_rates ─────────────────────────────────────────────────
CREATE POLICY "fx_rates: all can read" ON fx_rates
  FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "fx_rates: admin write" ON fx_rates
  FOR ALL USING (get_my_role() = 'admin');

-- ─── benchmark_peers ──────────────────────────────────────────
CREATE POLICY "peers: all can read active" ON benchmark_peers
  FOR SELECT USING (is_active = true AND auth.uid() IS NOT NULL);

CREATE POLICY "peers: admin write" ON benchmark_peers
  FOR ALL USING (get_my_role() = 'admin');

-- ─── user_sessions ────────────────────────────────────────────
CREATE POLICY "sessions: own rows" ON user_sessions
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "sessions: insert own" ON user_sessions
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "sessions: admin all" ON user_sessions
  FOR ALL USING (get_my_role() = 'admin');

-- ─── data_uploads ─────────────────────────────────────────────
CREATE POLICY "uploads: admin all" ON data_uploads
  FOR ALL USING (get_my_role() = 'admin');

CREATE POLICY "uploads: own read" ON data_uploads
  FOR SELECT USING (uploaded_by = auth.uid());

-- ─── ai_chat_history ──────────────────────────────────────────
CREATE POLICY "chat: own only" ON ai_chat_history
  FOR ALL USING (user_id = auth.uid());

-- ─── dashboard_preferences ────────────────────────────────────
CREATE POLICY "prefs: own only" ON dashboard_preferences
  FOR ALL USING (user_id = auth.uid());
