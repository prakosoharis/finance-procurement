# Procurement P&L Intelligence Dashboard
## Berau Coal Energy — Corporate Procurement Analytics

### Quick Start
1. Open `index.html` in a modern browser (Chrome / Edge recommended)
2. Click **📂 Upload XLS** and select your procurement database file
3. All tabs update automatically with your data

### What's Included
- **10 Dashboard Tabs**: Actual vs Target, P&L+ROI, P&L Report, Charts, FX Rates, YoY, Insights, Ratios, Peer Parity, Permissions, AI Assistant
- **9 UI Themes**: Dark, Minimalist, Glassmorphism, Skeuomorphism, Neo-Brutalism, Bento, Y2K, Nature, Kinetic
- **Export Formats**: Excel (.xlsx), PDF, PowerPoint (.pptx) with embedded BCG-style charts
- **AI Assistant**: Claude Sonnet integration (works inside claude.ai)
- **BI JISDOR FX**: Live USD↔IDR conversion with Bank Indonesia rates

### Divisions Supported
- **SMM** — Mining procurement
- **SUN** — Energy procurement  
- **OliveLink** — Sourcing middleman
- **Combine** — Auto-aggregated (SMM + SUN + OliveLink)

### Upload Format
See `templates/upload_template.html` for the required Excel format.
The Database sheet must have these columns:
`Business Unit · Budget/Actual · Period · Year · Cost Saving · Cost Avoidance · Total Value Creation · Initial SUM · SUM after Saving · Net Value Creation · Salaries · Housing Fund · Social Security · Rent Exp · Prof. Service Fee · Property Management Fee · Legal Advisory Fee · Business Trip · License & Permit · IT Expense · Entertainment · Office Expense · Communication · Repair Maintenance · Insurance · Revenue · GP`

### ROI Benchmarks
- World Class: ≥900% (≥9×) — Hackett Group
- Excellent: 500–900% (5–9×)
- Good: 300–500% (3–5×)
- Average: 100–300% (1–3×)

### Tech Stack (Production Version)
See `docs/tech_spec.html` for the full technical blueprint.
- **Frontend**: Next.js 14, TypeScript, TailwindCSS, Zustand, TanStack Query
- **Backend**: Supabase (PostgreSQL + Auth + Storage + Realtime)
- **AI**: Anthropic Claude Sonnet via server-side proxy
- **Charts**: Chart.js 4.4

### Support
Built in collaboration with CHA (Yang Caroline Hanna), CFO of IT & Procurement, PT Berau Coal Energy.
