# Setup Guide — Procurement P&L Dashboard

## Option A: Use as Static HTML (Recommended for quick start)

### Step 1: Open the dashboard
Simply open `index.html` in Chrome or Edge browser.
No server, no installation, no dependencies required.

### Step 2: Upload your data
1. Click the green **📂 Upload XLS** button (top-right of header)
2. Select your `Proc database.xlsx` or `Database for Claude.xlsx` file
3. The file must have a sheet named **Database** with the correct columns
4. All tabs refresh automatically — takes 2–5 seconds

### Step 3: Use filters
- **Division**: Combine / SMM / SUN / OliveLink
- **Year**: All / 2022–2026
- **Period**: All / Q1–Q4 / FY / YTD Q2 / YTD Q3
- **Currency**: USD (Millions) ↔ IDR (Billions) using BI JISDOR rates

### Step 4: Export reports
- **⬇ Excel**: Full P&L with styled cells (all periods)
- **⬇ PDF**: Board-ready 5-page report with color-coded tables
- **⬇ PPT**: PowerPoint deck with embedded BCG-style charts
- **⬇ Report PDF / PPT**: P&L + ROI Report in the exact format shown in reference image

---

## Option B: Production Full-Stack (Next.js + Supabase)

See `docs/tech_spec.html` for the complete Technical Specification.

### Prerequisites
- Node.js 18+
- A Supabase account (supabase.com)
- A Vercel account (vercel.com)

### Step 1: Database setup
```sql
-- Run in Supabase SQL Editor:
-- 1. database/schema.sql       (create all 12 tables)
-- 2. database/seed_data.sql    (seed divisions, periods, FX rates, benchmarks)
-- 3. database/rls_policies.sql (enable Row-Level Security)
```

### Step 2: Environment variables
Create `.env.local`:
```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
ANTHROPIC_API_KEY=sk-ant-...
NEXT_PUBLIC_APP_URL=https://your-app.vercel.app
```

### Step 3: Deploy
```bash
npx create-next-app@latest procurement-dashboard --typescript --tailwind --app
cd procurement-dashboard
npm install @supabase/supabase-js zustand @tanstack/react-query
npm install chart.js xlsx-js-style jspdf pptxgenjs
vercel deploy
```

### Migration Timeline
- Phase 0: Setup (1 week)
- Phase 1–2: Database + Auth (10 days)
- Phase 3–4: Data layer + UI (5 weeks)
- Phase 5–8: Charts, exports, AI, UAT (4 weeks)
**Total: ~12 weeks solo / 8 weeks with 2-person team**

---

## XLS Upload Troubleshooting

| Issue | Solution |
|-------|----------|
| "Could not find header row" | Make sure sheet is named exactly **Database** |
| Numbers show as zero | Check values are numeric, not text-formatted |
| Division not appearing | Use exactly: SMM, SUN, OliveLink (case-sensitive) |
| FY totals wrong | The parser reconstructs FY from Q1+Q2+Q3+Q4 automatically |
| Combine missing | Combine is auto-built — do NOT include Combine rows in your file |

---

## Known Limitations (Static HTML version)
- Data resets on page refresh (no persistent storage)
- AI Assistant requires the claude.ai environment to reach Anthropic API
- Theme preference resets on refresh (localStorage removed for publish compatibility)
- Maximum recommended file size: 10 MB

Contact: caroline.hanna@beraucoal.co.id
